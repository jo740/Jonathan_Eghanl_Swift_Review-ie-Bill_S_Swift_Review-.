import UIKit

import UIKit
//Variables
var name = "Jonathan Eghan"

//Constanst
let language = "Swift"

//Operators
let a = 2

let b = 5

let c = 7

let d = Double(2.7)

let e = Double(7.8)

let f = Double(0.23345463)

a + Int(e) + c + b

a - c

Int(e) / a

b * Int(b)
//If Statements
let temperature = 90
let raining = true
let time = "Morning"

if temperature < 80{
    print("Wear jeans!")
}
if temperature > 80{
    print("Wear shorts!")
}
if raining == true {
    print( "You need an umbrella!")
}

if raining == false {
    print( "You don't need an umbrella")
}

if time == "Morning" {
    print( "Time to go to school!")
    }

if time == "Afternoon"{
    print( "Time to go home")
}

if time == "Night" {
    print( "Time for bed")
}
//Loops


var numbers = 1

while numbers <= 10{
    print("Number \(numbers)")
    numbers = numbers + 1
}
if numbers == 10 {
    print("End")
}
if numbers > 10{
    numbers = 10
}


while numbers >= 10{
    print("Number \(numbers)")
    numbers = numbers - 1
}
if numbers == 10 {
    print("End")
}
if numbers < 10{
    numbers = 10
}
//Collections

var silverware : [String] = ["Spoons", "Fork", "Knife", "butterKnife", "steakKnife"]

for (index, value) in silverware.enumerated() {
    print("Item \(index + 1): \(value)")
}
//Functions

func multiplyingOperation() {
    let sum = Int(d) * Int(f)
    print(sum)
}

multiplyingOperation()

//Closures

var subtractingOp: () {

    let g = a - b
    print("\(g)")
}
subtractingOp


//Enums
enum teamNames: String {
    case Aidan = "07.30.2004",
         Alex = "07.02.2004", Cuiying = "11.15.2003", Michon = "01.04.2004", Jonathan = "04.01.2004", Yasmine = "09.19.2003"
}
let birthday : teamNames = .Yasmine

switch birthday{
    
case .Aidan:
    print("Aidan's Birthday is \(teamNames.Aidan)")
case .Alex:
    print("Alex's Birthday is \(teamNames.Alex)")
case .Cuiying:
    print("Cuiying's Birthday is \(teamNames.Cuiying)")
case .Michon:
    print("Michon's Birthday \(teamNames.Michon)")
case .Yasmine:
    print("Yasmine's Birthday is \(teamNames.Yasmine.rawValue)")
    
}


//Structure
struct name2 {
    var first : String
    var middle : String
    var last : String
}
   
let Jonathan = name2(first: " Jonathan ", last: " Eghan ")
print(Jonathan.first + Jonathan.last)


//Class

class coffee {
    var size = "Large"
    var caffineated = "caffineated"
    var cream = "cream"
    var sugar = "sugar"
    

func order() {
    print("\(size) \(caffineated) \(cream) \(sugar)")
}
}
var black = coffee()
black.order()
